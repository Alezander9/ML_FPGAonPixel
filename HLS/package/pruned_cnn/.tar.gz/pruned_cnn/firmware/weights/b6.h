//Numpy array shape [4]
//Min -0.177246093750
//Max 0.032836914062
//Number of zeros 0

#ifndef B6_H_
#define B6_H_

#ifndef __SYNTHESIS__
bias6_t b6[4];
#else
bias6_t b6[4] = {-0.90365600585938, 1.66366577148438, -0.77627563476562, 0.46228027343750};
#endif

#endif
