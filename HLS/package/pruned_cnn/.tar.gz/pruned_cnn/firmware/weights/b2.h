//Numpy array shape [2]
//Min 0.000305175781
//Max 0.000335693359
//Number of zeros 0

#ifndef B2_H_
#define B2_H_

#ifndef __SYNTHESIS__
bias2_t b2[2];
#else
bias2_t b2[2] = {0.74191284179688, 0.01986694335938};
#endif

#endif
