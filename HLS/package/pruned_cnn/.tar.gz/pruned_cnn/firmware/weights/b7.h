//Numpy array shape [8]
//Min -0.074407726526
//Max 0.032618146390
//Number of zeros 0

#ifndef B7_H_
#define B7_H_

#ifndef __SYNTHESIS__
conv2_bias_t b7[8];
#else
conv2_bias_t b7[8] = {2.2923145294, 0.6461805701, 2.4157145023, -0.2619683146, 2.6665596962, 1.1029940844, 0.8340272903, -1.1921787262};
#endif

#endif
