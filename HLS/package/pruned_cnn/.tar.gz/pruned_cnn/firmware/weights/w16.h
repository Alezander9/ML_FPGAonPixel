//Numpy array shape [4, 1]
//Min -3.342132568359
//Max 2.059387207031
//Number of zeros 1

#ifndef W16_H_
#define W16_H_

#ifndef __SYNTHESIS__
weight16_t w16[4];
#else
weight16_t w16[4] = {2.05938720703125, 0.00000000000000, -3.34213256835938, -0.81283569335938};
#endif

#endif
