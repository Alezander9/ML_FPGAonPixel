//Numpy array shape [4]
//Min -2.603613853455
//Max 0.241170912981
//Number of zeros 0

#ifndef A17_H_
#define A17_H_

#ifndef __SYNTHESIS__
model_default_t a17[4];
#else
model_default_t a17[4] = {-1.1745172739, 0.1643480659, -2.6036138535, 0.2411709130};
#endif

#endif
