//Numpy array shape [4]
//Min -0.575500488281
//Max 0.264190673828
//Number of zeros 0

#ifndef B13_H_
#define B13_H_

#ifndef __SYNTHESIS__
bias13_t b13[4];
#else
bias13_t b13[4] = {-0.57550048828125, 0.21920776367188, -0.18869018554688, 0.26419067382812};
#endif

#endif
