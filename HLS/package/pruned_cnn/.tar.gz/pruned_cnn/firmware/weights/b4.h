//Numpy array shape [4]
//Min -0.594682157040
//Max 2.087635040283
//Number of zeros 0

#ifndef B4_H_
#define B4_H_

#ifndef __SYNTHESIS__
bn1_bias_t b4[4];
#else
bn1_bias_t b4[4] = {-0.5946821570, 1.1280813217, 2.0876350403, 1.9470986128};
#endif

#endif
