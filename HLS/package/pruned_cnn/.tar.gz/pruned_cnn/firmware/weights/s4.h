//Numpy array shape [4]
//Min 0.000054584238
//Max 0.000660499034
//Number of zeros 0

#ifndef S4_H_
#define S4_H_

#ifndef __SYNTHESIS__
bn1_scale_t s4[4];
#else
bn1_scale_t s4[4] = {0.0006604990, 0.0001125015, 0.0000545842, 0.0000546997};
#endif

#endif
