//Numpy array shape [8]
//Min -0.322313070297
//Max 1.710861325264
//Number of zeros 0

#ifndef B9_H_
#define B9_H_

#ifndef __SYNTHESIS__
bn2_bias_t b9[8];
#else
bn2_bias_t b9[8] = {0.8526322246, 1.7108613253, -0.0324695036, 0.7176918983, -0.3223130703, 0.7236859798, 1.3643637896, 0.2061321288};
#endif

#endif
