//Numpy array shape [1]
//Min 0.358092844486
//Max 0.358092844486
//Number of zeros 0

#ifndef B18_H_
#define B18_H_

#ifndef __SYNTHESIS__
output_sigmoid_bias_t b18[1];
#else
output_sigmoid_bias_t b18[1] = {0.3580928445};
#endif

#endif
