//Numpy array shape [4]
//Min 0.004997904412
//Max 0.223639264703
//Number of zeros 0

#ifndef B15_H_
#define B15_H_

#ifndef __SYNTHESIS__
dense_bias_t b15[4];
#else
dense_bias_t b15[4] = {0.1359630078, 0.2236392647, 0.0432882458, 0.0049979044};
#endif

#endif
