//Numpy array shape [7]
//Min -0.148437500000
//Max 0.148437500000
//Number of zeros 0

#ifndef B13_H_
#define B13_H_

#ifndef __SYNTHESIS__
bias13_t b13[7];
#else
bias13_t b13[7] = {-0.1406250, -0.1484375, 0.0781250, 0.1484375, -0.1328125, -0.0625000, 0.0625000};
#endif

#endif
