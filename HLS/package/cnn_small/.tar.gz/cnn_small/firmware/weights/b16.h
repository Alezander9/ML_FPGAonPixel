//Numpy array shape [1]
//Min -0.671875000000
//Max -0.671875000000
//Number of zeros 0

#ifndef B16_H_
#define B16_H_

#ifndef __SYNTHESIS__
bias16_t b16[1];
#else
bias16_t b16[1] = {-0.6718750};
#endif

#endif
