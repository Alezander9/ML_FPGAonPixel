//Numpy array shape [4]
//Min -0.343750000000
//Max 0.218750000000
//Number of zeros 0

#ifndef B2_H_
#define B2_H_

#ifndef __SYNTHESIS__
bias2_t b2[4];
#else
bias2_t b2[4] = {-0.0312500, 0.2187500, -0.3437500, 0.1015625};
#endif

#endif
