//Numpy array shape [13, 1]
//Min -4.000000000000
//Max 3.140625000000
//Number of zeros 3

#ifndef W16_H_
#define W16_H_

#ifndef __SYNTHESIS__
weight16_t w16[13];
#else
weight16_t w16[13] = {0.0000000, 2.8984375, -3.8984375, -2.5703125, -4.0000000, 0.0000000, 1.8906250, 2.8828125, -1.1250000, 3.1406250, -3.8671875, 0.0000000, 0.8671875};
#endif

#endif
