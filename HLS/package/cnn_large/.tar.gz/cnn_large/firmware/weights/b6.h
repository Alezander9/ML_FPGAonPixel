//Numpy array shape [13]
//Min -0.289062500000
//Max 0.421875000000
//Number of zeros 1

#ifndef B6_H_
#define B6_H_

#ifndef __SYNTHESIS__
bias6_t b6[13];
#else
bias6_t b6[13] = {0.0000000, 0.4062500, 0.2343750, 0.0468750, 0.2265625, 0.0859375, -0.2890625, -0.2187500, 0.1250000, 0.0468750, 0.4218750, 0.0937500, -0.0468750};
#endif

#endif
